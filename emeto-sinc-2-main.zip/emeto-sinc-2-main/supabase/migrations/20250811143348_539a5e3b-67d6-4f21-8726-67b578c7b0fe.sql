
create or replace function public.create_invitation(
  _name text,
  _email text,
  _user_type text,
  _professional_type text default null
)
returns public.invitations
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_row public.invitations;
begin
  -- Requer usuário autenticado
  if auth.uid() is null then
    raise exception 'Você precisa estar autenticado para criar convites';
  end if;

  -- Admin não pode ser criado via convite
  if lower(coalesce(_user_type, '')) = 'admin' then
    raise exception 'Admin só pode ser criado diretamente no sistema';
  end if;

  insert into public.invitations (name, email, user_type, professional_type, invited_by)
  values (_name, _email, _user_type, _professional_type, auth.uid())
  returning * into v_row;

  return v_row;
end;
$$;

-- Observação:
-- Não é necessário criar políticas extras de UPDATE/DELETE para este fluxo,
-- pois "mark_invitation_used" já é uma RPC SECURITY DEFINER
-- e "delete_expired_invitations" também roda no servidor.
