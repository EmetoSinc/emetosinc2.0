-- Enable required extensions
create extension if not exists pgcrypto with schema extensions;
create extension if not exists pg_cron with schema extensions;

-- Generic updated_at trigger function
create or replace function public.update_updated_at_column()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- Create user_profiles table (if not exists)
create table if not exists public.user_profiles (
  id uuid not null primary key,
  email text not null unique,
  name text not null,
  role text not null check (role in ('gestor','profissional','flebotomista','atendente')),
  professional_type text,
  cpf text not null,
  rg text not null,
  birth_date date not null,
  gender text not null check (gender in ('masculino','feminino','outro')),
  phone text not null,
  professional_registry text,
  address jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Enable RLS and policies for user_profiles
alter table public.user_profiles enable row level security;

create policy if not exists "Users can view their own profile"
  on public.user_profiles
  for select
  to authenticated
  using (auth.uid() = id);

create policy if not exists "Users can insert their own profile"
  on public.user_profiles
  for insert
  to authenticated
  with check (auth.uid() = id);

create policy if not exists "Users can update their own profile"
  on public.user_profiles
  for update
  to authenticated
  using (auth.uid() = id);

-- Trigger for updated_at
drop trigger if exists update_user_profiles_updated_at on public.user_profiles;
create trigger update_user_profiles_updated_at
before update on public.user_profiles
for each row
execute function public.update_updated_at_column();

-- Invitations table
create table if not exists public.invitations (
  id uuid primary key default gen_random_uuid(),
  token uuid unique not null default gen_random_uuid(),
  name text not null,
  email text not null,
  user_type text not null check (user_type in ('gestor','profissional','flebotomista','atendente')),
  professional_type text,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours'),
  used boolean not null default false,
  invited_by uuid references auth.users(id),
  constraint email_not_admin check (lower(email) <> 'emeto@admin.com')
);

alter table public.invitations enable row level security;

-- Invitations policies (creator can manage their invites)
create policy if not exists "Inviter can view their invitations"
  on public.invitations
  for select
  to authenticated
  using (invited_by = auth.uid());

create policy if not exists "Authenticated can create invitations"
  on public.invitations
  for insert
  to authenticated
  with check (invited_by = auth.uid());

-- RPC: validate invitation token (SECURITY DEFINER to bypass RLS safely)
create or replace function public.validate_invitation_token(_token uuid)
returns public.invitations
language sql
security definer
set search_path = public, extensions
stable
as $$
  select *
  from public.invitations
  where token = _token
    and used = false
    and expires_at > now()
  limit 1
$$;

grant execute on function public.validate_invitation_token(uuid) to anon, authenticated;

-- RPC: mark invitation as used
create or replace function public.mark_invitation_used(_token uuid)
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  update public.invitations
  set used = true
  where token = _token;
end;
$$;

grant execute on function public.mark_invitation_used(uuid) to anon, authenticated;

-- Maintenance: delete expired invitations
create or replace function public.delete_expired_invitations()
returns void
language plpgsql
security definer
set search_path = public, extensions
as $$
begin
  delete from public.invitations
  where expires_at < now() and used = false;
end;
$$;

grant execute on function public.delete_expired_invitations() to anon, authenticated;

-- Ensure a fresh cron schedule then (re)schedule hourly cleanup
-- Safe unschedule if already exists
DO $$
BEGIN
  IF exists (select 1 from cron.job where jobname = 'delete-expired-invitations') THEN
    PERFORM cron.unschedule('delete-expired-invitations');
  END IF;
END$$;

select cron.schedule(
  'delete-expired-invitations',
  '0 * * * *',
  $$select public.delete_expired_invitations();$$
);
