import React, { useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { notify } from "@/lib/notify";
import ButtonsDemo from "@/components/demos/ButtonsDemo";
import IconButtonsDemo from "@/components/demos/IconButtonsDemo";
import { CheckCircle2, XCircle, FlaskConical } from "lucide-react";

export default function Teste() {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Gate: only in DEV or specific admin email
  const canSeeDev = useMemo(
    () => import.meta.env.DEV || user?.email === "emeto@admin.com",
    [user?.email]
  );

  useEffect(() => {
    document.title = "Ambiente de Testes | emetosinc";
  }, []);

  useEffect(() => {
    if (!canSeeDev) {
      navigate("/painel", { replace: true });
    }
  }, [canSeeDev, navigate]);

  if (!canSeeDev) return null;

  return (
    <main className="container mx-auto py-8">
      <header className="mb-6 flex items-center gap-2">
        <FlaskConical className="h-5 w-5 text-primary" aria-hidden />
        <h1 className="text-2xl font-semibold tracking-tight">Ambiente de Testes</h1>
      </header>

      <section aria-labelledby="sec-acoes" className="mb-8">
        <h2 id="sec-acoes" className="mb-3 text-base font-medium text-muted-foreground">
          Ações rápidas
        </h2>
        <div className="flex flex-wrap gap-3">
          <Button variant="outline" onClick={() => notify.success("Tudo certo", "Operação concluída com sucesso.")}>Sucesso</Button>
          <Button variant="destructive" onClick={() => notify.error("Erro ao processar", "Ocorreu um problema.")}>Erro</Button>
          <Button variant="outline" onClick={() => notify.warning("Atenção", "Exemplo de aviso.")}>Aviso</Button>
          <Button variant="outline" onClick={() => notify.info("Informação", "Exemplo informativo.")}>Info</Button>
        </div>
      </section>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        <section aria-labelledby="sec-botoes">
          <Card>
            <CardHeader>
              <CardTitle id="sec-botoes" className="text-lg">
                Botões
              </CardTitle>
              <CardDescription>Variações principais do componente Button.</CardDescription>
            </CardHeader>
            <CardContent>
              <ButtonsDemo />
              <p className="mt-3 text-sm text-muted-foreground">
                Tokens: --btn-min-w, border-input, bg-sidebar, text-sidebar-foreground.
              </p>
            </CardContent>
          </Card>
        </section>

        <section aria-labelledby="sec-inputs">
          <Card>
            <CardHeader>
              <CardTitle id="sec-inputs" className="text-lg">
                Inputs
              </CardTitle>
              <CardDescription>Exemplo básico de Label + Input.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="nome">Nome</Label>
                  <Input id="nome" placeholder="Digite seu nome" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="nome@dominio.com" />
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <section aria-labelledby="sec-icon-buttons">
          <Card>
            <CardHeader>
              <CardTitle id="sec-icon-buttons" className="text-lg">
                Botões de ícone
              </CardTitle>
              <CardDescription>Botões sem texto, apenas ícones, com fundo e borda para padronização.</CardDescription>
            </CardHeader>
            <CardContent>
              <IconButtonsDemo />
            </CardContent>
          </Card>
        </section>
      </div>

      <section aria-labelledby="sec-card" className="mt-6">
        <Card>
          <CardHeader>
            <CardTitle id="sec-card" className="text-lg">
              Cartão de demonstração
            </CardTitle>
            <CardDescription>Use este espaço para testar componentes rapidamente.</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-3">
            <Button
              variant="outline"
              onClick={() =>
                notify.success("Ação concluída", "Exemplo de confirmação.")
              }
            >
              <CheckCircle2 className="mr-2 h-4 w-4" /> Confirmar
            </Button>
            <Button
              variant="outline"
              onClick={() =>
                notify.info("Operação cancelada", "Exemplo informativo.")
              }
            >
              <XCircle className="mr-2 h-4 w-4" /> Cancelar
            </Button>
          </CardContent>
        </Card>
      </section>
    </main>
  );
}
