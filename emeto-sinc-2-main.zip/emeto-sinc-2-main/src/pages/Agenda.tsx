import React, { useEffect } from "react";

const Agenda = () => {
  useEffect(() => {
    document.title = "Agenda - EmetoSinc CRM";
  }, []);

  return (
    <div className="container-default py-8">
      {/* Página em branco */}
    </div>
  );
};

export default Agenda;