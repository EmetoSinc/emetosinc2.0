import React, { useEffect } from "react";

const Pacientes = () => {
  useEffect(() => {
    document.title = "Pacientes - EmetoSinc CRM";
  }, []);

  return (
    <div className="container-default py-8">
      {/* Página em branco */}
    </div>
  );
};

export default Pacientes;