import React, { useEffect, useMemo, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import MaskedInput from "@/components/ui/MaskedInput";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { notify } from "@/lib/notify";
import { supabase } from "@/integrations/supabase/client";
import { validateInvitationToken, markInvitationUsed, getRegistryMaskFromSubtype, Invitation } from "@/lib/invitations";
import { cpfSchema, rgSchema, phoneSchema, birthDateMaskedStringSchema, validateProfessionalRegistry } from "@/lib/validators";
import { useAutoFillAddress } from "@/hooks/useViaCep";

// Step schemas
const passwordSchema = z.string()
  .min(8, 'Senha deve ter pelo menos 8 caracteres')
  .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/, 'Senha deve ter maiúscula, minúscula e número');

const registrationSchema = z.object({
  // Step 1
  password: passwordSchema,
  confirmPassword: z.string(),
  // Step 2
  cpf: cpfSchema,
  rg: rgSchema,
  birthDate: birthDateMaskedStringSchema, // masked string -> Date via schema
  gender: z.enum(['masculino','feminino','outro']),
  phone: phoneSchema,
  professionalRegistry: z.string().optional(),
  // Step 3 (optional)
  cep: z.string().optional(),
  number: z.string().optional(),
  street: z.string().optional(),
  neighborhood: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional(),
}).superRefine((val, ctx) => {
  if (val.confirmPassword !== val.password) {
    ctx.addIssue({ code: z.ZodIssueCode.custom, path: ['confirmPassword'], message: 'Senhas não coincidem' });
  }
});

type RegistrationData = z.infer<typeof registrationSchema>;

function InvitationExpired() {
  useEffect(() => { document.title = 'Convite inválido - EmetoSinc CRM'; }, []);
  return (
    <div className="container-default py-10">
      <h1 className="text-2xl font-semibold mb-2">Convite inválido ou expirado</h1>
      <p className="text-muted-foreground">Solicite um novo convite ao responsável pela sua clínica.</p>
    </div>
  );
}

function Loading() {
  return (
    <div className="container-default py-10">
      <p className="text-muted-foreground">Validando convite…</p>
    </div>
  );
}

export default function Registro() {
  const [params] = useSearchParams();
  const token = params.get('token') || '';
  const navigate = useNavigate();

  const { data: invitation, isLoading } = useQuery({
    queryKey: ['invitation', token],
    queryFn: () => validateInvitationToken(token),
    enabled: !!token,
  });

  const [step, setStep] = useState(1);

  useEffect(() => {
    document.title = 'Registro - EmetoSinc CRM';
  }, []);

  const form = useForm<RegistrationData>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      password: '',
      confirmPassword: '',
      cpf: '',
      rg: '',
      birthDate: new Date() as any,
      gender: 'outro',
      phone: '',
      professionalRegistry: '',
      cep: '', number: '', street: '', neighborhood: '', city: '', state: ''
    }
  });

  const cep = form.watch('cep');
  useAutoFillAddress(cep, (addr) => {
    form.setValue('street', addr.street);
    form.setValue('neighborhood', addr.neighborhood);
    form.setValue('city', addr.city);
    form.setValue('state', addr.state);
  });

  const isProfessional = (invitation?.user_type === 'profissional');
  const registryMask = getRegistryMaskFromSubtype(invitation?.professional_type || undefined);

  const next = async () => {
    // Validate fields for the current step only
    if (step === 1) {
      const { password, confirmPassword } = form.getValues();
      const res = await form.trigger(['password','confirmPassword']);
      if (!res) return;
      if (password !== confirmPassword) return;
      setStep(2);
    } else if (step === 2) {
      const fields: (keyof RegistrationData)[] = ['cpf','rg','birthDate','gender','phone'];
      if (isProfessional) fields.push('professionalRegistry');
      const res = await form.trigger(fields as any);
      if (!res) return;
      // Optional: validate registry for professionals by mask/type if provided
      if (isProfessional && registryMask) {
        const reg = form.getValues('professionalRegistry') || '';
        const ok = validateProfessionalRegistry(reg, registryMask as any);
        if (!ok) {
          form.setError('professionalRegistry', { message: 'Registro profissional inválido' });
          return;
        }
      }
      setStep(3);
    }
  };

  const back = () => setStep((s) => Math.max(1, s - 1));

  const onSubmit = async (values: RegistrationData) => {
    if (!invitation) return;
    try {
      // 1) Create Auth user
      const redirectUrl = `${window.location.origin}/`;
      const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
        email: invitation.email,
        password: values.password,
        options: { emailRedirectTo: redirectUrl }
      });
      if (signUpError) throw signUpError;
      const userId = signUpData.user?.id;
      if (!userId) {
        notify.info('Cadastro iniciado', 'Confirme seu email para concluir o registro.');
        return;
      }

      // 2) Create profile
      const profile = {
        id: userId,
        email: invitation.email,
        name: invitation.name,
        role: invitation.user_type,
        professional_type: invitation.professional_type,
        cpf: values.cpf,
        rg: values.rg,
        birth_date: (values.birthDate as unknown as Date),
        gender: values.gender,
        phone: values.phone,
        professional_registry: values.professionalRegistry || null,
        address: values.cep ? {
          cep: values.cep,
          number: values.number,
          street: values.street,
          neighborhood: values.neighborhood,
          city: values.city,
          state: values.state
        } : null
      } as any;

      const { error: profErr } = await supabase.from('user_profiles').insert(profile);
      if (profErr) throw profErr;

      // 3) Mark invite as used
      await markInvitationUsed(invitation.token);

      notify.success('Registro completo', 'Você já pode acessar o sistema.');
      navigate('/painel');
    } catch (e: any) {
      notify.error('Erro no registro', e.message || 'Tente novamente mais tarde.');
    }
  };

  if (isLoading) return <Loading />;
  if (!token || !invitation) return <InvitationExpired />;

  return (
    <div className="container-default py-8">
      <header className="mb-6">
        <h1 className="text-2xl font-semibold">Registro de Convite</h1>
        <p className="text-sm text-muted-foreground">Convite para {invitation.name} ({invitation.email}) – perfil: {invitation.user_type}{invitation.professional_type ? ` / ${invitation.professional_type}` : ''}</p>
      </header>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {step === 1 && (
            <section className="space-y-4">
              <FormField name="password" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>Senha</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="Digite sua senha" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField name="confirmPassword" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>Confirmar senha</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="Confirme sua senha" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </section>
          )}

          {step === 2 && (
            <section className="grid gap-4 md:grid-cols-2">
              <FormField name="cpf" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>CPF</FormLabel>
                  <FormControl>
                    <MaskedInput mask="cpf" value={field.value} onChange={field.onChange} placeholder="000.000.000-00" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              
              <FormField name="rg" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>RG</FormLabel>
                  <FormControl>
                    <MaskedInput mask="rg" value={field.value} onChange={field.onChange} placeholder="00.000.000-0" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField name="birthDate" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>Data de Nascimento</FormLabel>
                  <FormControl>
                    <MaskedInput mask="birthDate" value={field.value as any} onChange={field.onChange} placeholder="dd/mm/aaaa" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField name="gender" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>Gênero</FormLabel>
                  <FormControl>
                    <Select value={field.value} onValueChange={field.onChange}>
                      <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                      <SelectContent className="z-50 bg-background">
                        <SelectItem value="masculino">Masculino</SelectItem>
                        <SelectItem value="feminino">Feminino</SelectItem>
                        <SelectItem value="outro">Outro</SelectItem>
                      </SelectContent>
                    </Select>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              <FormField name="phone" control={form.control} render={({ field }) => (
                <FormItem className="md:col-span-2">
                  <FormLabel>Telefone</FormLabel>
                  <FormControl>
                    <MaskedInput mask="phone" value={field.value} onChange={field.onChange} placeholder="(00) 00000-0000" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />

              {isProfessional && (
                <FormField name="professionalRegistry" control={form.control} render={({ field }) => (
                  <FormItem className="md:col-span-2">
                    <FormLabel>Registro Profissional</FormLabel>
                    <FormControl>
                      <MaskedInput mask={(registryMask as any) || 'number'} value={field.value || ''} onChange={field.onChange} placeholder="Informe seu registro" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              )}
            </section>
          )}

          {step === 3 && (
            <section className="grid gap-4 md:grid-cols-2">
              <FormField name="cep" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>CEP</FormLabel>
                  <FormControl>
                    <MaskedInput mask="cep" value={field.value || ''} onChange={field.onChange} placeholder="00000-000" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField name="number" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>Número</FormLabel>
                  <FormControl>
                    <Input type="text" placeholder="Número" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField name="street" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>Logradouro</FormLabel>
                  <FormControl>
                    <Input placeholder="Rua" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField name="neighborhood" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>Bairro</FormLabel>
                  <FormControl>
                    <Input placeholder="Bairro" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField name="city" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>Cidade</FormLabel>
                  <FormControl>
                    <Input placeholder="Cidade" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
              <FormField name="state" control={form.control} render={({ field }) => (
                <FormItem>
                  <FormLabel>Estado</FormLabel>
                  <FormControl>
                    <Input placeholder="UF" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )} />
            </section>
          )}

          <div className="flex items-center gap-3">
            {step > 1 && (
              <Button type="button" variant="secondary" onClick={back}>Voltar</Button>
            )}
            {step < 3 && (
              <Button type="button" onClick={next}>Continuar</Button>
            )}
            {step === 3 && (
              <Button type="submit">Concluir</Button>
            )}
          </div>
        </form>
      </Form>
    </div>
  );
}
