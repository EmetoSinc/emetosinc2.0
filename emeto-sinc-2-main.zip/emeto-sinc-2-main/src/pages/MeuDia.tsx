import React, { useEffect } from "react";

const MeuDia = () => {
  useEffect(() => {
    document.title = "Meu dia - EmetoSinc CRM";
  }, []);

  return (
    <div className="container-default py-8">
      {/* Página em branco */}
    </div>
  );
};

export default MeuDia;