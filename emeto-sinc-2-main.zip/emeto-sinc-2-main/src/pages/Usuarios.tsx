import React, { useEffect } from "react";
import { InviteModal } from "@/components/invitations/InviteModal";

const Usuarios = () => {
  useEffect(() => {
    document.title = "Usuários - EmetoSinc CRM";
  }, []);

  return (
    <div className="container-default py-8 space-y-4">
      <h1 className="text-2xl font-semibold">Usuários</h1>
      <InviteModal />
    </div>
  );
};

export default Usuarios;