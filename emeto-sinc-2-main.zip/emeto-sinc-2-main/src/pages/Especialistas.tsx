import React, { useEffect } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form } from "@/components/ui/form";
import { NonIntrusiveFormField } from "@/components/ui/non-intrusive-form-field";
import { useNonIntrusiveForm } from "@/hooks/useNonIntrusiveForm";
import MaskedInput from "@/components/ui/MaskedInput";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { notify } from "@/lib/notify";
import {
  validateCPF,
  validateProfessionalRegistry,
  errorMessages,
} from "@/lib/validators";
import { useAutoFillAddress } from "@/hooks/useViaCep";

const registryTypes = ["crm", "crp", "crn", "crefito", "crefono"] as const;
type RegistryType = typeof registryTypes[number];

const schema = z
  .object({
    name: z.string().min(3, "Nome é obrigatório"),
    cpf: z
      .string()
      .regex(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/, errorMessages.cpf.format)
      .refine(validateCPF, errorMessages.cpf.invalid),
    registryType: z.enum(registryTypes),
    registry: z.string().min(1, errorMessages.registry.invalid),
    phone: z
      .string()
      .optional()
      .or(z.literal("").transform(() => undefined)),
    cep: z
      .string()
      .regex(/^\d{5}-\d{3}$/, errorMessages.cep.format)
      .refine(async (cep) => {
        const { valid } = await (await import("@/lib/validators")).validateCEP(cep);
        return valid;
      }, errorMessages.cep.notFound),
    street: z.string().optional(),
    neighborhood: z.string().optional(),
    city: z.string().optional(),
    state: z.string().optional(),
  })
  .superRefine((data, ctx) => {
    if (!validateProfessionalRegistry(data.registry, data.registryType)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ["registry"],
        message: (errorMessages.registry as any)[data.registryType] || errorMessages.registry.invalid,
      });
    }
  });

type FormValues = z.infer<typeof schema>;

const Especialistas = () => {
  useEffect(() => {
    document.title = "Especialistas - EmetoSinc CRM";
  }, []);

  const { form, handleSubmit, handleInputChange, showErrors } = useNonIntrusiveForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: "",
      cpf: "",
      registryType: "crm",
      registry: "",
      phone: "",
      cep: "",
      street: "",
      neighborhood: "",
      city: "",
      state: "",
    },
  });

  const cepValue = form.watch("cep");

  useAutoFillAddress(cepValue, (addr) => {
    form.setValue("street", addr.street, { shouldDirty: true });
    form.setValue("neighborhood", addr.neighborhood, { shouldDirty: true });
    form.setValue("city", addr.city, { shouldDirty: true });
    form.setValue("state", addr.state, { shouldDirty: true });
  });

  const selectedType = form.watch("registryType");

  const onSubmit = async (values: FormValues) => {
    notify.success("Especialista salvo", `${values.name} cadastrado com sucesso.`);
    // Aqui você pode integrar com sua API/Supabase futuramente
  };

  return (
    <div className="container-default py-8">
      <main className="space-y-6">
        {/* Conteúdo removido conforme solicitado */}
      </main>
    </div>
  );
};

export default Especialistas;
