import React from "react";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { notify } from "@/lib/notify";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardDescription } from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { NonIntrusiveFormField } from "@/components/ui/non-intrusive-form-field";
import { useNonIntrusiveForm } from "@/hooks/useNonIntrusiveForm";
import { Eye, EyeOff } from "lucide-react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

const schema = z.object({
  email: z.string().email("E-mail inválido"),
  password: z.string().min(6, "Mínimo de 6 caracteres"),
  remember: z.boolean().optional().default(false),
});

type FormValues = z.infer<typeof schema>;

const Index = () => {
  const [showPassword, setShowPassword] = React.useState(false);
  const [isLoading, setIsLoading] = React.useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { signIn, user, loading } = useAuth();
  
  const {
    form,
    handleInputChange,
    handleSubmit,
    shouldShowFieldError
  } = useNonIntrusiveForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { email: "", password: "", remember: false },
  });

React.useEffect(() => {
  document.title = "Login | EmetoSinc";
  const ensureMeta = (name: string, content: string) => {
    let el = document.querySelector(`meta[name="${name}"]`) as HTMLMetaElement | null;
    if (!el) {
      el = document.createElement("meta");
      el.setAttribute("name", name);
      document.head.appendChild(el);
    }
    el.setAttribute("content", content);
  };
  ensureMeta("description", "Login do CRM EmetoSinc");

  let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
  if (!canonical) {
    canonical = document.createElement("link");
    canonical.setAttribute("rel", "canonical");
    document.head.appendChild(canonical);
  }
  canonical.setAttribute("href", window.location.href);
}, []);

// Redireciona se já estiver autenticado
React.useEffect(() => {
  const from = (location.state as any)?.from?.pathname ?? "/painel";
  if (!loading && user) {
    navigate(from, { replace: true });
  }
}, [user, loading, location.state, navigate]);

  const onSubmit = async (values: FormValues) => {
    try {
      setIsLoading(true);
      const { error } = await signIn(values.email, values.password);
      if (error) {
        throw error;
      }
      const from = (location.state as any)?.from?.pathname ?? "/painel";
      notify.success("Bem-vindo!", values.email);
      navigate(from, { replace: true });
    } catch (e: any) {
      const msg = e?.message || "Não foi possível entrar. Verifique suas credenciais.";
      notify.error("Erro ao entrar", msg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-background flex items-center justify-center p-8">
      <section className="w-full max-w-2xl grid grid-cols-2 overflow-hidden rounded-xl border bg-card shadow-sm">
        {/* Coluna esquerda: formulário */}
        <div className="flex flex-col">
          {/* DIV SUPERIOR: Logo */}
          <div className="px-6" style={{ paddingTop: '1.2rem', paddingBottom: '.75rem' }}>
            <header>
              <span className="inline-flex items-center gap-2 text-sm font-bold">
                <svg xmlns="http://www.w3.org/2000/svg" width="9" height="14" viewBox="0 0 239 382" fill="none" className="flex-shrink-0">
                  <path d="M239 174.705V209.545L239 241.705C239 243.75 237 245.196 235.058 244.554L181.498 226.847C180.922 226.657 180.301 226.645 179.718 226.815L71.3842 258.375C70.8522 258.53 70.4864 259.017 70.4864 259.572C70.4864 260.126 70.8522 260.613 71.3842 260.768L236.839 308.968C238.12 309.341 239 310.514 239 311.848V378.849C239 380.893 237 382.339 235.058 381.697L2.05832 304.667C0.829708 304.261 0 303.113 0 301.819V217.323C0 216.029 0.829721 214.881 2.05833 214.475L64.451 193.848C67.1954 192.941 67.1954 189.059 64.451 188.151L2.05832 167.524C0.829714 167.118 0 165.97 0 164.676V80.181C0 78.887 0.829718 77.7388 2.05833 77.3326L235.058 0.303113C237 -0.338656 239 1.10692 239 3.15149V70.1521C239 71.4858 238.12 72.6594 236.839 73.0324L71.3842 121.232C70.8522 121.387 70.4864 121.874 70.4864 122.428C70.4864 122.983 70.8522 123.47 71.3842 123.625L180.613 155.445L236.839 171.825C238.12 172.198 239 173.372 239 174.705Z" fill="hsl(var(--primary))" />
                </svg>
                <span className="-mt-0.5">emetosinc</span>
              </span>
            </header>
          </div>

          {/* DIV INFERIOR: Conteúdo do login */}
          <div className="px-6 py-3">
            <Card className="border-0 shadow-none p-6">
              <CardHeader className="p-0 mb-2">
                <h1 className="text-lg font-bold tracking-tight">Vamos Sincronizar!</h1>
                <CardDescription className="mt-0.5 text-xs pb-4">Insira suas credenciais para continuar.</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <Form {...form}>
                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
                    <NonIntrusiveFormField
                      control={form.control}
                      name="email"
                      label="E-mail"
                      showErrors={shouldShowFieldError("email")}
                      handleInputChange={handleInputChange}
                    >
                      {(field) => (
                        <Input 
                          type="email" 
                          placeholder="seu@email.com" 
                          autoComplete="email" 
                          {...field}
                        />
                      )}
                    </NonIntrusiveFormField>

                    <NonIntrusiveFormField
                      control={form.control}
                      name="password"
                      label="Senha"
                      showErrors={shouldShowFieldError("password")}
                      handleInputChange={handleInputChange}
                    >
                      {(field) => (
                        <div className="relative">
                          <Input
                            type={showPassword ? "text" : "password"}
                            placeholder="sua senha"
                            autoComplete="current-password"
                            {...field}
                          />
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            className="btn-icon absolute right-1.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:bg-transparent hover:text-muted-foreground hover:border-transparent"
                            onClick={() => setShowPassword((v) => !v)}
                            aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
                          >
                            {showPassword ? <EyeOff /> : <Eye />}
                          </Button>
                        </div>
                      )}
                    </NonIntrusiveFormField>


                    <Button type="submit" className="w-full py-1.5 text-sm mt-2" disabled={isLoading}>
                      <motion.div whileHover={{ y: -1 }} whileTap={{ y: 0 }}>
                        {isLoading ? 'Entrando…' : 'Entrar'}
                      </motion.div>
                    </Button>

                    <div className="text-xs text-center mt-3">
                      <span className="text-muted-foreground">Esqueceu sua senha? </span>
                      <a href="#" className="text-primary">Clique aqui</a>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Coluna direita: logo */}
        <aside className="relative flex items-center justify-center bg-primary text-primary-foreground p-4">
          <div className="pointer-events-none absolute inset-0 opacity-20" aria-hidden>
            <div className="absolute -left-12 -top-12 size-48 rounded-full bg-primary-foreground/10 blur-3xl" />
            <div className="absolute right-0 bottom-0 size-56 rounded-full bg-primary-foreground/10 blur-3xl" />
          </div>
          <div className="relative">
            <svg xmlns="http://www.w3.org/2000/svg" width="94" height="144" viewBox="0 0 239 382" fill="none" className="flex-shrink-0">
              <path d="M239 174.705V209.545L239 241.705C239 243.75 237 245.196 235.058 244.554L181.498 226.847C180.922 226.657 180.301 226.645 179.718 226.815L71.3842 258.375C70.8522 258.53 70.4864 259.017 70.4864 259.572C70.4864 260.126 70.8522 260.613 71.3842 260.768L236.839 308.968C238.12 309.341 239 310.514 239 311.848V378.849C239 380.893 237 382.339 235.058 381.697L2.05832 304.667C0.829708 304.261 0 303.113 0 301.819V217.323C0 216.029 0.829721 214.881 2.05833 214.475L64.451 193.848C67.1954 192.941 67.1954 189.059 64.451 188.151L2.05832 167.524C0.829714 167.118 0 165.97 0 164.676V80.181C0 78.887 0.829718 77.7388 2.05833 77.3326L235.058 0.303113C237 -0.338656 239 1.10692 239 3.15149V70.1521C239 71.4858 238.12 72.6594 236.839 73.0324L71.3842 121.232C70.8522 121.387 70.4864 121.874 70.4864 122.428C70.4864 122.983 70.8522 123.47 71.3842 123.625L180.613 155.445L236.839 171.825C238.12 172.198 239 173.372 239 174.705Z" fill="white" />
            </svg>
          </div>
        </aside>
      </section>
    </main>
  );
};

export default Index;
