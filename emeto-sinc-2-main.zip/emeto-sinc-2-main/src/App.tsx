import React from "react";
import { Toaster } from "@/components/ui/toaster";

import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Layout } from "@/components/Layout";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import Index from "./pages/Index";

import Painel from "./pages/Painel";
import MeuDia from "./pages/MeuDia";
import FilaEspera from "./pages/FilaEspera";
import Agenda from "./pages/Agenda";
import Pacientes from "./pages/Pacientes";
import Especialistas from "./pages/Especialistas";
import Procedimentos from "./pages/Procedimentos";
import Usuarios from "./pages/Usuarios";
import NotFound from "./pages/NotFound";
import Registro from "./pages/Registro";
import Teste from "./pages/Teste";

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <Toaster />
      
<AuthProvider>
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<Index />} />
      
      <Route path="/painel" element={<ProtectedRoute><Layout><Painel /></Layout></ProtectedRoute>} />
      <Route path="/meu-dia" element={<ProtectedRoute><Layout><MeuDia /></Layout></ProtectedRoute>} />
      <Route path="/fila-de-espera" element={<ProtectedRoute><Layout><FilaEspera /></Layout></ProtectedRoute>} />
      <Route path="/agenda" element={<ProtectedRoute><Layout><Agenda /></Layout></ProtectedRoute>} />
      <Route path="/pacientes" element={<ProtectedRoute><Layout><Pacientes /></Layout></ProtectedRoute>} />
      <Route path="/especialistas" element={<ProtectedRoute><Layout><Especialistas /></Layout></ProtectedRoute>} />
      <Route path="/procedimentos" element={<ProtectedRoute><Layout><Procedimentos /></Layout></ProtectedRoute>} />
      <Route path="/usuarios" element={<ProtectedRoute><Layout><Usuarios /></Layout></ProtectedRoute>} />
      <Route path="/teste" element={<ProtectedRoute><Layout><Teste /></Layout></ProtectedRoute>} />
      <Route path="/registro" element={<Registro />} />

      <Route path="*" element={<NotFound />} />
    </Routes>
  </BrowserRouter>
</AuthProvider>
    </QueryClientProvider>
  );
};

export default App;
