import React from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";

export function AppHeader() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut();
    navigate("/", { replace: true });
  };

  return (
    <header
      className="fixed inset-x-0 top-0 h-14 bg-sidebar border-b border-sidebar-border z-10"
      aria-label="App header"
    >
      <div className="h-full w-full flex items-center justify-end px-4">
        {user && (
          <div className="flex items-center gap-3">
            <span className="text-sm text-sidebar-foreground/80">{user.email}</span>
            <Button variant="secondary" size="sm" onClick={handleLogout}>Sair</Button>
          </div>
        )}
      </div>
    </header>
  );
}
