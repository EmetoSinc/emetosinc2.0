import React from "react";
import { Button } from "@/components/ui/button";
import { Search, Settings, Trash2 } from "lucide-react";

export default function IconButtonsDemo() {
  return (
    <div className="flex flex-wrap items-center gap-3">
      <Button
        variant="outline"
        size="icon"
        className="btn-icon btn-icon-zoom"
        aria-label="Buscar"
        title="Buscar"
      >
        <Search aria-hidden />
      </Button>

      <Button
        variant="outline"
        size="icon"
        className="btn-icon btn-icon-zoom"
        aria-label="Configurações"
        title="Configurações"
      >
        <Settings aria-hidden />
      </Button>

      <Button
        variant="outline"
        size="icon"
        className="btn-icon btn-icon-zoom"
        aria-label="Excluir"
        title="Excluir"
      >
        <Trash2 aria-hidden />
      </Button>
    </div>
  );
}
