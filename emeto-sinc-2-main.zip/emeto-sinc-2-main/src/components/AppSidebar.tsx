import React, { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  Calendar,
  Clock,
  Users,
  UserCheck,
  Stethoscope,
  FileText,
  Settings,
  Layers2,
  Heart,
  Pocket,
  Cross,
  HandHeart,
  Glasses,
  FlaskConical,
} from "lucide-react";

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarSeparator,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter as DialogFooterUI,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";

import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";

const menuItems = [
  { title: "Painel", url: "/painel", icon: Layers2 },
  { title: "Meu dia", url: "/meu-dia", icon: Clock },
  { title: "Fila de espera", url: "/fila-de-espera", icon: Pocket },
  { title: "Agenda", url: "/agenda", icon: Calendar },
  { title: "Pacientes", url: "/pacientes", icon: Users },
  { title: "Especialistas", url: "/especialistas", icon: Cross },
  { title: "Procedimentos", url: "/procedimentos", icon: HandHeart },
  { title: "Usuários", url: "/usuarios", icon: Glasses },
];

export function AppSidebar() {
  const location = useLocation();
  const currentPath = location.pathname;
  const [isHovered, setIsHovered] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const { user } = useAuth();
  const canSeeDev = import.meta.env.DEV || user?.email === "emeto@admin.com";
  const items = canSeeDev ? [...menuItems, { title: "Teste", url: "/teste", icon: FlaskConical }] : menuItems;

  const isActive = (path: string) => currentPath === path;
  const shouldShowText = isHovered && !settingsOpen;
  const getNavClass = (navProps: { isActive: boolean }) =>
    navProps.isActive 
      ? "bg-[hsl(230_98%_52%)] text-white font-medium rounded-xl" 
      : "hover:bg-sidebar-accent/50 text-sidebar-foreground";

  return (
    <Sidebar
      className={`fixed inset-y-0 left-0 z-50 border-r border-sidebar-border transition-all duration-300 ease-in-out overflow-x-hidden ${
        shouldShowText ? "sidebar-expanded" : "sidebar-collapsed"
      }`}
      collapsible="none"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <SidebarContent className="overflow-x-hidden">
        {/* Logo Section */}
        <div className="pb-2" style={{ paddingTop: '0.8rem', paddingLeft: '1.2rem', paddingRight: '0.75rem' }}>
          <div className="flex items-center gap-2">
            <div className="flex items-center justify-center flex-shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" width="16" height="26" viewBox="0 0 239 382" fill="none" className="flex-shrink-0">
                <path d="M239 174.705V209.545L239 241.705C239 243.75 237 245.196 235.058 244.554L181.498 226.847C180.922 226.657 180.301 226.645 179.718 226.815L71.3842 258.375C70.8522 258.53 70.4864 259.017 70.4864 259.572C70.4864 260.126 70.8522 260.613 71.3842 260.768L236.839 308.968C238.12 309.341 239 310.514 239 311.848V378.849C239 380.893 237 382.339 235.058 381.697L2.05832 304.667C0.829708 304.261 0 303.113 0 301.819V217.323C0 216.029 0.829721 214.881 2.05833 214.475L64.451 193.848C67.1954 192.941 67.1954 189.059 64.451 188.151L2.05832 167.524C0.829714 167.118 0 165.97 0 164.676V80.181C0 78.887 0.829718 77.7388 2.05833 77.3326L235.058 0.303113C237 -0.338656 239 1.10692 239 3.15149V70.1521C239 71.4858 238.12 72.6594 236.839 73.0324L71.3842 121.232C70.8522 121.387 70.4864 121.874 70.4864 122.428C70.4864 122.983 70.8522 123.47 71.3842 123.625L180.613 155.445L236.839 171.825C238.12 172.198 239 173.372 239 174.705Z" fill="hsl(var(--primary))" />
              </svg>
            </div>
              <span
                className={`font-semibold text-[1.1rem] text-sidebar-foreground whitespace-nowrap overflow-hidden transition-all duration-300 ${shouldShowText ? 'max-w-[200px] opacity-100' : 'max-w-0 opacity-0'}`}
              >
                emetosinc
              </span>
          </div>
        </div>

        <SidebarSeparator className="mx-0 w-full" />

        {/* Menu Section */}
        <SidebarGroup>
          <SidebarGroupContent className="flex justify-center">
            <div style={{ paddingLeft: '0.2rem', paddingRight: '0.3rem' }} className="w-full">
              <SidebarMenu>
                {items.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      className={`${currentPath === item.url
                        ? 'relative isolate overflow-hidden rounded-[var(--radius)] font-medium text-white transition-all duration-200 before:absolute before:inset-0 before:bg-gradient-to-br before:from-primary before:via-primary/95 before:to-primary/80 before:content-[\'\'] before:rounded-[var(--radius)] before:z-0 before:origin-left before:scale-x-100 before:transition-transform before:duration-300 before:ease-in-out before:will-change-transform shadow-[inset_0_1px_2px_0_rgba(255,255,255,0.08),0_2px_4px_-1px_rgba(0,0,0,0.06),0_1px_2px_-1px_rgba(0,0,0,0.04)] after:absolute after:inset-0 after:rounded-[var(--radius)] after:bg-gradient-to-b after:from-white/8 after:to-transparent after:pointer-events-none after:z-10'
                        : 'relative isolate overflow-hidden rounded-[var(--radius)] text-sidebar-foreground transition-all duration-500 ease-in-out before:absolute before:inset-0 before:bg-gradient-to-br before:from-primary before:via-primary/95 before:to-primary/80 before:content-[\'\'] before:rounded-[var(--radius)] before:z-0 before:origin-left before:scale-x-0 before:transition-transform before:duration-300 before:ease-in-out before:will-change-transform after:absolute after:inset-0 after:rounded-[var(--radius)] after:bg-gradient-to-b after:from-transparent after:to-transparent after:pointer-events-none after:z-10 after:transition-all after:duration-500 after:ease-in-out hover:bg-sidebar-accent/30 hover:shadow-[inset_0_1px_2px_0_rgba(255,255,255,0.06),0_1px_3px_0_rgba(0,0,0,0.08),0_1px_2px_0_rgba(0,0,0,0.05)] hover:after:bg-gradient-to-b hover:after:from-white/6 hover:after:to-transparent'}`}
                    >
                      <NavLink to={item.url} end>
                        <item.icon className={`relative z-10 h-4 w-4 flex-shrink-0 ${currentPath === item.url ? 'text-white hover:text-white' : ''} ${item.icon === Pocket ? 'rotate-90' : ''}`} />
                        <span
                          className={`relative z-10 ml-2 overflow-hidden whitespace-nowrap transition-all duration-300 ${shouldShowText ? 'max-w-[200px] opacity-100' : 'max-w-0 opacity-0'} ${currentPath === item.url ? 'text-white hover:text-white' : ''}`}
                        >
                          {item.title}
                        </span>
                      </NavLink>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </div>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarFooter className="mt-auto p-0">
          <SidebarSeparator className="mx-0 w-full" />
          <div className="px-3 pb-3">
            <Dialog open={settingsOpen} onOpenChange={(open) => { setSettingsOpen(open); if (open) setIsHovered(false); }}>
              <SidebarMenu>
                <SidebarMenuItem>
                  <DialogTrigger asChild>
                    <SidebarMenuButton className="relative isolate overflow-hidden rounded-[var(--radius)] text-sidebar-foreground transition-all duration-200 hover:bg-sidebar-accent/30 hover:shadow-[inset_0_1px_2px_0_rgba(255,255,255,0.06),0_1px_3px_0_rgba(0,0,0,0.08),0_1px_2px_0_rgba(0,0,0,0.05)] hover:after:bg-gradient-to-b hover:after:from-white/6 hover:after:to-transparent after:absolute after:inset-0 after:rounded-[var(--radius)] after:bg-gradient-to-b after:from-transparent after:to-transparent after:pointer-events-none after:z-10 after:transition-all after:duration-200">
                      <Settings className="relative z-20 h-4 w-4 flex-shrink-0" />
                      <span
                        className={`relative z-20 ml-2 overflow-hidden whitespace-nowrap transition-all duration-300 ${shouldShowText ? 'max-w-[200px] opacity-100' : 'max-w-0 opacity-0'}`}
                      >
                        Configurações
                      </span>
                    </SidebarMenuButton>
                  </DialogTrigger>
                </SidebarMenuItem>
              </SidebarMenu>

              <DialogContent className="animate-enter">
                <DialogHeader>
                  <DialogTitle>Configurações</DialogTitle>
                  <DialogDescription>
                    Ajustes do sistema e preferências.
                  </DialogDescription>
                </DialogHeader>
                <div className="mt-4">
                  <p className="text-sm text-muted-foreground">
                    Aqui você poderá ajustar preferências da aplicação. (Conteúdo de exemplo)
                  </p>
                </div>
                <DialogFooterUI>
                  <DialogClose asChild>
                    <Button variant="secondary">Fechar</Button>
                  </DialogClose>
                  <DialogClose asChild>
                    <Button type="button">Salvar</Button>
                  </DialogClose>
                </DialogFooterUI>
              </DialogContent>
            </Dialog>
          </div>
        </SidebarFooter>

      </SidebarContent>
    </Sidebar>
  );
}