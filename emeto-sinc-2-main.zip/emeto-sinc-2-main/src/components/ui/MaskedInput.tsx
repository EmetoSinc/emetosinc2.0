import React from "react";
import { Input } from "@/components/ui/input";
import { useMask, MaskType } from "@/hooks/useMask";
import { cn } from "@/lib/utils";

export interface MaskedInputProps
  extends Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "value" | "type"> {
  mask: MaskType;
  value: string;
  onChange: (value: string) => void;
  className?: string;
}

function getMaskPlaceholder(type: MaskType): string {
  switch (type) {
    case "cpf":
      return "000.000.000-00";
    case "rg":
      return "00.000.000-0";
    case "birthDate":
      return "DD/MM/AAAA";
    case "phone":
      return "(00) 00000-0000";
    case "cep":
      return "00000-000";
    case "crm":
      return "000000/UF";
    case "crp":
      return "00/000000";
    case "crn":
      return "0-0000/UF";
    case "crefito":
      return "000000-F/UF";
    case "crefono":
      return "0-00000/UF";
    case "number":
      return "Somente números";
    default:
      return "";
  }
}

export const MaskedInput: React.FC<MaskedInputProps> = ({
  mask,
  value,
  onChange,
  className,
  placeholder,
  ...props
}) => {
  const { formatValue, sanitizeValue, allowLetters } = useMask(mask);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    const sanitized = sanitizeValue(raw);
    const formatted = formatValue(sanitized);
    onChange(formatted);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    const controlKeys = [
      "Backspace",
      "Delete",
      "Tab",
      "ArrowLeft",
      "ArrowRight",
      "Home",
      "End",
    ];

    if (controlKeys.includes(e.key) || (e.ctrlKey || e.metaKey)) return;

    // Allow only digits by default; for some masks allow letters in UF part
    const isDigit = /\d/.test(e.key);
    const isLetter = /[a-zA-Z]/.test(e.key);

    if (allowLetters) {
      if (!isDigit && !isLetter) e.preventDefault();
    } else {
      if (!isDigit) e.preventDefault();
    }
  };

  return (
    <Input
      {...props}
      inputMode={allowLetters ? undefined : "numeric"}
      autoCapitalize={allowLetters ? "characters" : undefined}
      value={value}
      onChange={handleChange}
      onKeyDown={handleKeyDown}
      placeholder={placeholder ?? getMaskPlaceholder(mask)}
      className={cn(className)}
    />
  );
};

export default MaskedInput;
