import * as React from "react"
import { useToast } from "@/hooks/use-toast"
import {
  Toast,
  ToastClose,
  ToastDescription,
  ToastProvider,
  ToastTitle,
  ToastViewport,
} from "@/components/ui/toast"
import { CheckCircle2, XCircle, AlertTriangle, Info } from "lucide-react"

function ToastMeta({
  duration,
  createdAt,
  paused,
  remaining,
  colorClass,
}: {
  duration: number
  createdAt?: number
  paused?: boolean
  remaining?: number
  colorClass: string
}) {
  const [now, setNow] = React.useState(() => Date.now())

  React.useEffect(() => {
    if (paused) return
    const i = setInterval(() => setNow(Date.now()), 250)
    return () => clearInterval(i)
  }, [paused])

  const total = duration || 4000
  const initialTotalRef = React.useRef(total)
  const start = createdAt ?? now
  const rem = paused
    ? Math.max(0, remaining ?? total)
    : Math.max(0, total - (now - start))
  const percent = Math.max(0, Math.min(100, (rem / initialTotalRef.current) * 100))

  return (
    <div className="absolute inset-x-0 bottom-0 h-1 bg-muted/30 overflow-hidden">
      <div
        className={`h-full ${colorClass}`}
        style={{ width: `${percent}%`, transition: paused ? "none" : "width 250ms linear" }}
      />
    </div>
  )
}

export function Toaster() {
  const { toasts, dismiss, pause, resume } = useToast()

  return (
    <ToastProvider duration={4000}>
      <ToastViewport>
        {toasts.map(function ({ id, title, description, action, ...props }) {
          const variant = (props as any).variant as
            | "error"
            | "success"
            | "warning"
            | "info"
            | "destructive"
            | undefined

          const Icon =
            variant === "success"
              ? CheckCircle2
              : variant === "destructive" || variant === "error"
              ? XCircle
              : variant === "warning"
              ? AlertTriangle
              : variant === "info"
              ? Info
              : null

          const iconClass =
            variant === "destructive" || variant === "error"
              ? "text-destructive"
              : variant === "success"
              ? "text-success"
              : variant === "warning"
              ? "text-warning"
              : variant === "info"
              ? "text-info"
              : "text-muted-foreground"

          const barClass =
            variant === "destructive" || variant === "error"
              ? "bg-destructive"
              : variant === "success"
              ? "bg-success"
              : variant === "warning"
              ? "bg-warning"
              : variant === "info"
              ? "bg-info"
              : "bg-muted-foreground"

          const duration = (props as any).duration ?? 4000
          const closing = (props as any).closing as boolean | undefined
          const createdAt = (props as any).createdAt as number | undefined
          const isPaused = (props as any).paused as boolean | undefined
          const remaining = (props as any).remaining as number | undefined

          return (
            <Toast
              key={id}
              {...props}
              className={`relative overflow-hidden ${closing ? 'animate-slide-out-right' : 'animate-slide-in-right'}`}
            >
              <div className="flex items-start gap-2 pr-6">
                {Icon ? (
                  <Icon className={`h-4 w-4 mt-0.5 ${iconClass}`} aria-hidden />
                ) : null}
                <div className="grid gap-0.5">
                  {title && <ToastTitle className="text-sm">{title}</ToastTitle>}
                  {description && (
                    <ToastDescription className="text-xs">{description}</ToastDescription>
                  )}
                </div>
              </div>
              {action}
              <ToastClose onClick={() => dismiss(id)} />
              <ToastMeta
                duration={duration}
                createdAt={createdAt}
                paused={isPaused}
                remaining={remaining}
                colorClass={barClass}
              />
            </Toast>
          )
        })}
      </ToastViewport>
    </ToastProvider>
  )
}
