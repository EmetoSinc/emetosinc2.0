import React from "react";
import {
  FormField as BaseFormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form";
import { ControllerProps, FieldPath, FieldValues } from "react-hook-form";

interface NonIntrusiveFormFieldProps<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
> extends Omit<ControllerProps<TFieldValues, TName>, 'render'> {
  label?: string;
  showErrors?: boolean;
  handleInputChange?: (onChange: (value: any) => void) => (value: any) => void;
  children: (field: any) => React.ReactNode;
}

/**
 * Enhanced FormField that automatically applies non-intrusive validation behavior.
 * Integrates seamlessly with useNonIntrusiveForm hook.
 */
export function NonIntrusiveFormField<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
>({
  label,
  showErrors = true,
  handleInputChange,
  children,
  ...props
}: NonIntrusiveFormFieldProps<TFieldValues, TName>) {
  return (
    <BaseFormField
      {...props}
      render={({ field, fieldState }) => (
        <FormItem>
          {label && <FormLabel>{label}</FormLabel>}
          <FormControl>
            {children({
              ...field,
              onChange: handleInputChange 
                ? handleInputChange(field.onChange)
                : field.onChange
            })}
          </FormControl>
          {fieldState.error && showErrors && field.value && (
            <FormMessage />
          )}
        </FormItem>
      )}
    />
  );
}