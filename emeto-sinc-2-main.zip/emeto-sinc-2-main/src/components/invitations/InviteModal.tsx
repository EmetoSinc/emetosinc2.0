import React from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { notify } from "@/lib/notify";
import { buildInviteUrl, createInvitation, ProfessionalSubtype, UserType } from "@/lib/invitations";

const PROFESSIONAL_OPTIONS: { label: string; value: ProfessionalSubtype }[] = [
  { label: 'Médico', value: 'medico' },
  { label: 'Psicólogo', value: 'psicologo' },
  { label: 'Nutricionista', value: 'nutricionista' },
  { label: 'Fisioterapeuta', value: 'fisioterapeuta' },
  { label: 'Esteticista', value: 'esteticista' },
  { label: 'Fonoaudiólogo', value: 'fonoaudiologo' },
  { label: 'Massoterapeuta', value: 'massoterapeuta' },
  { label: 'Terapeuta Ocupacional', value: 'terapeuta-ocupacional' },
  { label: 'Quiropraxista', value: 'quiropraxista' },
  { label: 'Acupunturista', value: 'acupunturista' },
  { label: 'Osteopata', value: 'osteopata' },
  { label: 'Psicanalista', value: 'psicanalista' },
];

export function InviteModal() {
  const [open, setOpen] = React.useState(false);
  const [submitting, setSubmitting] = React.useState(false);

  const [name, setName] = React.useState('');
  const [email, setEmail] = React.useState('');
  const [userType, setUserType] = React.useState<UserType>('gestor');
  const [professionalType, setProfessionalType] = React.useState<ProfessionalSubtype | ''>('');
  const isProfessional = userType === 'profissional';

  const reset = () => {
    setName(''); setEmail(''); setUserType('gestor'); setProfessionalType('');
  };

  const onSubmit = async () => {
    try {
      setSubmitting(true);
      if (!name || !email) {
        notify.warning('Campos obrigatórios', 'Informe nome e email.');
        return;
      }
      if (userType === 'profissional' && !professionalType) {
        notify.warning('Selecione o subtipo', 'Escolha o subtipo de profissional.');
        return;
      }

      const invitation = await createInvitation({
        name,
        email,
        user_type: userType,
        professional_type: isProfessional ? professionalType : undefined,
      });

      const url = buildInviteUrl(invitation.token);
      await navigator.clipboard.writeText(url);
      notify.success('Convite criado', 'Link copiado para a área de transferência.');
      setOpen(false);
      reset();
    } catch (e: any) {
      notify.error('Erro ao criar convite', e.message || 'Verifique se você está autenticado.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button onClick={() => setOpen(true)}>Criar convite</Button>
      </DialogTrigger>
      <DialogContent className="z-50">
        <DialogHeader>
          <DialogTitle>Novo convite</DialogTitle>
          <DialogDescription>Envie um convite para um novo membro da equipe.</DialogDescription>
        </DialogHeader>

        <div className="grid gap-4">
          <div>
            <label className="mb-1 block text-sm">Nome completo</label>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome" />
          </div>
          <div>
            <label className="mb-1 block text-sm">Email</label>
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="email@exemplo.com" />
          </div>
          <div>
            <label className="mb-1 block text-sm">Tipo de usuário</label>
            <Select value={userType} onValueChange={(v: UserType) => setUserType(v)}>
              <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
              <SelectContent className="z-50 bg-background">
                <SelectItem value="gestor">Gestor</SelectItem>
                <SelectItem value="profissional">Profissional</SelectItem>
                <SelectItem value="flebotomista">Flebotomista</SelectItem>
                <SelectItem value="atendente">Atendente</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {isProfessional && (
            <div>
              <label className="mb-1 block text-sm">Subtipo de profissional</label>
              <Select value={professionalType} onValueChange={(v: ProfessionalSubtype) => setProfessionalType(v)}>
                <SelectTrigger><SelectValue placeholder="Selecione o subtipo" /></SelectTrigger>
                <SelectContent className="z-50 bg-background">
                  {PROFESSIONAL_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={onSubmit} disabled={submitting}>{submitting ? 'Criando…' : 'Criar convite'}</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
