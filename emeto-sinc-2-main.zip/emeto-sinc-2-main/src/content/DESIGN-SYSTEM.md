# Design System - Medical CRM

Status: Documentation (no UI changes in this commit)
Version: 1.0.0
Last updated: 2025-08-10

## Design Philosophy

### Core Principles
- Clean and Breathable - Layout with adequate spacing, avoiding overcrowded elements
- Highly Organized - Everything in its place, with a filled and fitted appearance
- Easy and Intuitive - Gamified interface, simple as a game
- Medical Trust - Visual that conveys safety and professionalism
- Productivity Focus - Efficient and fast workflow

### Visual Personality
- Modern and accessible (without conservative exaggeration)
- Calm and therapeutic (relaxing medical environment)
- Minimalist (Apple Health style - white, clean, subtle blue)

## Color System

### Primary Color
```css
--primary: hsl(230 98% 52%); /* Vibrant blue for highlights */
```

Applications:
- Primary buttons
- Specific highlight elements
- Active links
- Important icons

### Monochromatic System
- Base: Predominantly white and light tones
- Accents: Only primary blue for highlights
- Neutrals: Gray scale for text and borders

### Semantic Colors
- Success: --success / --success-foreground (confirmations, positive status)
- Warning: --warning / --warning-foreground (pending items, alerts)
- Info: --info / --info-foreground (informational)
- Error: --destructive / --destructive-foreground (cancellations, errors)

## Design Tokens

### Border Radius
```css
/* Standard for buttons, fields, cards */
--radius: 0.75rem; /* 12px */

/* Modals and larger elements */
--radius-modal: 1rem; /* 16px */
```

### Shadows
```css
/* Primary shadow for elements */
--shadow-primary: rgba(17, 12, 46, 0.15) 0px 48px 100px 0px;
```

Applications:
- Cards with special exceptions (when specified)
- Elements requiring elevation
- Default: Only thin borders; shadows by exception

### Borders
```css
--border: 214.3 31.8% 91.4%; /* Standard subtle border */
```

### Spacing
- Philosophy: Contextual and breathable
- Card separation: 1.5rem (24px) — general rule
- Varies by screen/page — some need more, others less

### Button Tokens
```css
/* Minimum width for text buttons */
--btn-min-w: 8rem; /* 128px default */
```
## Components - Buttons

### Text Buttons

#### Dimensions
```css
.btn {
  height: 40px; /* h-10 */
  min-width: var(--btn-min-w); /* Global token (default 8rem) */
  padding: 0 16px; /* px-4 - minimum, expands with content */
  border-radius: 0.75rem;
}
```

#### Tipografia
- Todos os botões de texto usam font-size text-sm por padrão.
- Os tamanhos (sm e lg) ajustam apenas o padding; a tipografia permanece text-sm.

#### Variants
- Primary: Cor primária com gradiente para ações principais.
- Secondary: Mesmo fundo do sidebar (bg-sidebar) + texto sidebar-foreground, com borda padrão (border-input) e hover escurecendo o fundo.
- Outline: Borda padrão (border-input) e hover com bg-sidebar + texto sidebar-foreground.
- Ghost: Borda transparente por padrão; no hover, aplica border-input e bg-sidebar + texto sidebar-foreground (evita "jump").
- Destructive: Gradiente a partir de destructive (from→via→to) com hover atenuado; texto destructive-foreground e sombra sutil consistente.
- Outros: Definir conforme necessário

#### Animações (globais)
- Text buttons (default, sm, lg): hover eleva 2px e active reduz para 95% com transição de 200ms.
- Acessibilidade: respeita prefers-reduced-motion (desativa transformações e animações).
- Shimmer: aplicado em variants com gradiente (default e destructive) usando animação lenta de background-position; classe: animate-btn-shimmer com bg-[length:200%_200%]; desativada com motion-reduce:animate-none.
### Icon Buttons

#### Dimensions
```css
.icon-btn {
  width: 32px;
  height: 32px; /* Small and compact */
  border-radius: 0.75rem; /* Follows project standard */
}
```

#### Internal icons
- Size: Proportional to button with breathable internal padding
- Colors: Standard gray (e.g., text-muted-foreground)
- Future: Specific colors per action (to be defined)

#### Visual style
```css
.icon-btn {
  border: 1px solid var(--border); /* Thin border */
  background: transparent;
}
```

#### Hover Effects
- Subtle combination of:
  - Icon color change
  - Lightly colored background
  - No exaggerated transformations

#### Mandatory tooltips
- Rule: Every icon button MUST have explanatory tooltip
- Position: Intelligent (adapts to available space)
- Delay: Fast and responsive

## Input Fields

### Dimensions
```css
.input {
  height: 40px; /* h-10 - standard for accessibility */
  min-height: 40px; /* ensures minimum touch target */
  border-radius: 0.75rem;
  border: 1px solid var(--border);
}

/* Compact variant for dense contexts only */
.input-compact {
  height: 32px; /* h-8 */
  min-height: 32px;
}
```

### States
- Normal: Standard subtle border
- Focus: Thin and clear outline (color to be defined — black or primary)
- Error: To be defined according to validation system

## Cards and Containers

### Standard structure
```css
.card {
  background: white;
  border: 1px solid var(--border);
  border-radius: 0.75rem;
  padding: 2.2rem; /* Generous internal space */
}
```

### Elevation
- Default: Only borders (clean visual)
- Exceptions: Shadow --shadow-primary when specified

### Hover
- Behavior: Subtle, no exaggerations
- Application: Only when necessary for interaction

## Typography

### Weights
```css
/* 3 weights when necessary */
--font-normal: 400;
--font-medium: 500;
--font-semibold: 600;
```

### Line height
```css
--leading-normal: 1.5; /* Balanced for reading */
```

### Letter spacing
```css
/* Tailwind default — no custom adjustments */
```

## Badges and Status

### Dimensions
```css
.badge {
  padding: 4px 8px; /* px-2 py-1 - small and discrete */
  font-size: 0.75rem; /* text-xs */
  border-radius: 0.75rem; /* Follows standard */
}
```

## Interactions and Animations

### Philosophy
- General: Fast transitions
- Exceptions: Some may be slower to improve experience
- Context: Duration depends on interaction importance

### Hover Effects
- Intensity: Subtle — only color change
- Avoid: Scale or exaggerated transformations
- Maintain: Clean and professional visual

### Focus States
- Style: Thin and clear outline
- Color: To be defined (tendency toward primary)
- Visibility: Always present for accessibility

## Specific Use Cases

### Search
- Magnifying glass icon: Inside field (right side)
- Style: Integrated with input, not as separate button

### Universal tooltips
- Mandatory: On every element that might cause doubt
- Positioning: Intelligent and adaptive
- Delay: Responsive, not too fast

## Usage Context

### Primary environment
- Mixed: Desktop, tablet, mobile as needed
- Users: Medium technological familiarity
- Context: Clinical environment (stress, multiple tasks, productivity)

### UX Priorities
1. Avoid user confusion
2. Prevent medical errors
3. Maintain high productivity
4. Ensure team adoption

## Accessibility

### Contrast
- Contextual: AAA for critical data, AA for secondary
- Flexibility: Adaptable according to information importance

### Interaction
- Touch areas: Minimum 40px for clickable elements
- Keyboard navigation: Full support
- Screen readers: Adequate semantics

## Governance

### Exception principle
- Standard: Always follow this design system
- Exceptions: Allowed when specified in project
- Documentation: Every exception must be justified

### Evolution
- Tokens: Centralized and reusable
- Components: Modular and extensible
- Feedback: Evolves with real usage

## Implementation Checklist

### For each new component
- [ ] Uses defined tokens for color, spacing, and radius
- [ ] Follows "clean and breathable" philosophy
- [ ] Has appropriate hover/focus states
- [ ] Works in medical context (stress, productivity)
- [ ] Maintains "organized and in place" visual
- [ ] Is "intuitive like a game"

### For each new screen
- [ ] Contextual spacing (more or less as needed)
- [ ] Clear visual hierarchy
- [ ] Elements in the right places
- [ ] Productive workflow
- [ ] Trustworthy visual for medical environment

## Design System Rules

### Mandatory implementation
- All components MUST use defined tokens
- Exception cases MUST be explicitly documented
- New additions MUST follow established patterns
- Visual consistency MUST be maintained across all screens

### Token usage
- Border radius: 0.75rem for standard elements; 1rem for modals
- Primary color: Only for highlights and primary actions
- Spacing: Contextual, generally 1.5rem between main elements
- Shadows: Only by exception, using the defined token

### Component standards
- Icon buttons: 32x32px with mandatory tooltips
- Text buttons: 40px height with contextual padding
- Cards: 2.2rem internal padding with border
- Inputs: 40px height standard, 32px compact variant for dense contexts

## Notificações (Toasts) — Padrão do Projeto

API pública
- Utilize SEMPRE `notify` de `src/lib/notify`.
- Métodos disponíveis: `notify.success`, `notify.error`, `notify.warning`, `notify.info`.
- Assinatura: `(title: string, description?: string, options?: { duration?: number; action?: ToastActionElement })`.

Comportamento padrão
- Apenas 1 toast visível por vez (fila limitada).
- Duração padrão: 4000ms.
- Animações: entrada `slide-in-right`, saída `slide-out-right` (ao clicar no X ou quando o tempo termina).
- Barra de progresso na base do toast.
- Não pausa ao passar o mouse.

Acessibilidade e semântica
- Botão de fechar com rótulo acessível.
- Ícones e cores semânticas por variante (success, warning, info, destructive/error) usando tokens do tema.

Boas práticas de conteúdo
- Título curto e direto; descrição opcional para complementar.
- Linguagem clara e útil para ação imediata.

Como usar
```ts
import { notify } from "@/lib/notify";

notify.success("Registro completo", "Você já pode acessar o sistema.", {
  duration: 6000,
});
```

Regras de engenharia (enforcement)
- É PROIBIDO importar `use-toast`/`toast` diretamente no app. O ESLint valida com `no-restricted-imports`.
- Exceções permitidas (internas ao sistema de toast):
  - `src/lib/notify.ts`
  - `src/components/ui/toaster.tsx`
  - `src/hooks/use-toast.ts`
  - `src/components/ui/use-toast.ts`
  - `src/components/ui/toast.tsx`

---

## Diagram (Mermaid)

```mermaid
graph LR
  A[Design Tokens<br/>--primary, --border,<br/>--radius, --shadow-primary] --> B[Tailwind Theme<br/>colors, borderRadius,<br/>boxShadow]
  B --> C[UI Components<br/>Button, Input, Card,<br/>Tooltip, Badge]
  C --> D[Pages & Flows<br/>Queue, Patients, Profile]
  D --> E[Metrics & Feedback]
  E --> A
```

---

## Technical Appendix (for developers)

This appendix maps the tokens from this document with what already exists in the project, to facilitate future implementation.

### Current token mapping (src/index.css)
- --primary: 230 98% 52% (already in use in light theme)
- --border: 214.3 31.8% 91.4% (coherent with subtle border)
- --ring: 230 98% 52% (aligned with primary focus)
- --radius: 0.5rem (current) — target of this document: 0.75rem
- Gradients: --gradient-primary, --gradient-background (already defined)
- Shadows: --shadow-glow and --shadow-tooltip (exist); add --shadow-primary

### Tailwind mapping (tailwind.config.ts)
- colors: mapped to hsl(var(--...)) — OK
- borderRadius: { lg: var(--radius), md: calc(var(--radius)-2px), sm: calc(var(--radius)-4px) }
- boxShadow: { glow: var(--shadow-glow) } — add future: primary: var(--shadow-primary)

### Usage examples (without changing components now)
- Primary button (40px):
  - Classes: inline-flex h-10 items-center rounded-lg px-4 bg-primary text-primary-foreground hover:bg-primary/90 transition-smooth
  - Note: rounded-lg uses var(--radius) via Tailwind; when var(--radius) migrates to 0.75rem, everything follows.
- Icon button (32px):
  - Classes: inline-flex size-8 items-center justify-center rounded-lg border border-border hover:bg-accent text-muted-foreground hover:text-foreground transition-smooth
- Standard input (40px):
  - Classes: flex h-10 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm
- Compact input (32px for dense contexts):
  - Classes: flex h-8 w-full rounded-lg border border-input bg-background px-3 py-1 text-sm
- Card with border (no shadow):
  - Classes: bg-card text-card-foreground rounded-lg border border-border p-9
- Shadow by exception:
  - Classes: shadow-[var(--shadow-primary)] (after defining in Tailwind)

### Compatibility notes
- Radius: current project uses 0.5rem; DS target is 0.75rem (and 1rem for modals). We'll adjust tokens later to propagate automatically.
- Dark mode: already exists; maintain AA/AAA contrast coherence according to Accessibility section.
- Inputs 40px standard/32px compact: respect minimum 40px touch area via containers and spacing, maintaining compact visual where necessary.

---

## Next steps (planned, not implemented here)
1. Add quick access shortcut/fab (bottom right corner) to Design System/UI Guide.
2. Create missing tokens: --radius-modal and --shadow-primary; map in Tailwind (additional borderRadius and boxShadow.primary).
3. Review main components (Button, Input, Card, Tooltip, Badge) to adhere to tokens and patterns.
4. Validate contrast (AA/AAA) in states and critical data.
5. Write basic visual tests (Chromatic/storyshots) for style regression.

---

This design system ensures visual consistency while maintaining the flexibility necessary for an efficient and trustworthy medical CRM.
