import React from "react";
import { validateCEP, ViaCepAddress } from "@/lib/validators";

/**
 * Debounced auto-fill address based on CEP.
 * When CEP reaches 9 chars (mask 00000-000), we hit ViaCEP and, if valid,
 * invoke onFill with the resolved address.
 */
export function useAutoFillAddress(
  cep: string | undefined,
  onFill: (address: ViaCepAddress) => void,
) {
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const timerRef = React.useRef<number | null>(null);
  const lastSuccessfulCepRef = React.useRef<string>("");

  React.useEffect(() => {
    const value = cep || "";

    // Only act when full masked CEP is present
    if (value.length !== 9) {
      setError(null);
      return;
    }

    if (lastSuccessfulCepRef.current === value) return;

    if (timerRef.current) window.clearTimeout(timerRef.current);

    timerRef.current = window.setTimeout(async () => {
      setLoading(true);
      const result = await validateCEP(value);
      setLoading(false);

      if ('address' in result) {
        lastSuccessfulCepRef.current = value;
        setError(null);
        onFill(result.address);
      } else if ('error' in result) {
        setError(result.error);
      } else {
        setError('Erro ao verificar CEP');
      }
    }, 400);

    return () => {
      if (timerRef.current) window.clearTimeout(timerRef.current);
    };
  }, [cep, onFill]);

  return { loading, error };
}
