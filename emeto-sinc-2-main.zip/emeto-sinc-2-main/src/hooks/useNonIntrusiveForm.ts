import React from "react";
import { useForm, UseFormProps, FieldValues, Path } from "react-hook-form";

/**
 * Custom hook that provides non-intrusive form validation.
 * Errors only show after submit attempts, not during typing.
 */
export function useNonIntrusiveForm<TFieldValues extends FieldValues = FieldValues>(
  props?: UseFormProps<TFieldValues>
) {
  const [showErrors, setShowErrors] = React.useState(false);

  // Configure form with non-intrusive defaults
  const form = useForm<TFieldValues>({
    mode: "onSubmit",
    reValidateMode: "onSubmit", 
    shouldFocusError: false,
    ...props,
  });

  // Hide errors when user types
  const handleInputChange = React.useCallback((onChange: (value: any) => void) => 
    (value: any) => {
      setShowErrors(false);
      onChange(value);
    }, []
  );

  // Enhanced submit handler that manages error visibility
  const handleSubmit = React.useCallback(
    (onValid: (data: TFieldValues) => void | Promise<void>) => 
      async (e: React.FormEvent) => {
        e.preventDefault();
        
        const isValid = await form.trigger();
        
        if (isValid) {
          const values = form.getValues();
          setShowErrors(false);
          await onValid(values);
        } else {
          setShowErrors(true);
        }
      },
    [form]
  );

  // Helper to check if field should show error
  const shouldShowFieldError = React.useCallback(
    (fieldName: Path<TFieldValues>) => {
      const fieldState = form.getFieldState(fieldName);
      const fieldValue = form.getValues(fieldName);
      
      return !!(fieldState.error && showErrors && fieldValue);
    },
    [form, showErrors]
  );

  return {
    form,
    showErrors,
    setShowErrors,
    handleInputChange,
    handleSubmit,
    shouldShowFieldError,
  };
}