export type MaskType =
  | "cpf"
  | "rg"
  | "birthDate"
  | "phone"
  | "cep"
  | "crm"
  | "crp"
  | "crn"
  | "crefito"
  | "crefono"
  | "number";

function onlyDigits(value: string) {
  return value.replace(/\D/g, "");
}

function onlyLetters(value: string) {
  return value.replace(/[^a-zA-Z]/g, "");
}

export function useMask(type: MaskType) {
  const allowLetters = ["crm", "crn", "crefito", "crefono"].includes(type);

  const sanitizeValue = (value: string) => {
    return allowLetters ? value.replace(/[^\da-zA-Z]/g, "") : onlyDigits(value);
  };

  const formatCPF = (digits: string) => {
    const v = digits.slice(0, 11);
    const p1 = v.slice(0, 3);
    const p2 = v.slice(3, 6);
    const p3 = v.slice(6, 9);
    const p4 = v.slice(9, 11);
    let out = p1;
    if (p2) out += (out ? "." : "") + p2;
    if (p3) out += (p2 ? "." : ".") + p3;
    if (p4) out += "-" + p4;
    return out;
  };

  const formatRG = (digits: string) => {
    const v = digits.slice(0, 9);
    const p1 = v.slice(0, 2);
    const p2 = v.slice(2, 5);
    const p3 = v.slice(5, 8);
    const p4 = v.slice(8, 9);
    let out = p1;
    if (p2) out += (out ? "." : "") + p2;
    if (p3) out += (p2 ? "." : ".") + p3;
    if (p4) out += "-" + p4;
    return out;
  };

  const formatBirthDate = (digits: string) => {
    const v = digits.slice(0, 8);
    const d = v.slice(0, 2);
    const m = v.slice(2, 4);
    const y = v.slice(4, 8);
    let out = d;
    if (m) out += (out ? "/" : "") + m;
    if (y) out += "/" + y;
    return out;
  };

  const formatPhone = (digits: string) => {
    const v = digits.slice(0, 11);
    const ddd = v.slice(0, 2);
    const rest = v.slice(2);

    if (!ddd) return v;

    let out = `(${ddd}`;
    if (rest.length === 0) return out + ")";

    const useFive = rest.length > 8; // 11-digit pattern
    const p1 = useFive ? rest.slice(0, 5) : rest.slice(0, 4);
    const p2 = rest.slice(useFive ? 5 : 4, useFive ? 9 : 8);

    out += `) ${p1}`;
    if (p2) out += `-${p2}`;
    return out;
  };

  const formatCEP = (digits: string) => {
    const v = digits.slice(0, 8);
    const p1 = v.slice(0, 5);
    const p2 = v.slice(5, 8);
    let out = p1;
    if (p2) out += `-${p2}`;
    return out;
  };

  const formatCRM = (value: string) => {
    const digits = onlyDigits(value).slice(0, 6);
    const letters = onlyLetters(value).toUpperCase().slice(0, 2);
    let out = digits;
    if (digits.length) out += "/";
    if (letters) out += letters;
    return out;
  };

  const formatCRP = (digits: string) => {
    const v = digits.slice(0, 8);
    const p1 = v.slice(0, 2);
    const p2 = v.slice(2, 8);
    let out = p1;
    if (p2) out += `/${p2}`;
    return out;
  };

  const formatCRN = (value: string) => {
    const digits = onlyDigits(value);
    const letters = onlyLetters(value).toUpperCase().slice(0, 2);
    const region = digits.slice(0, 1);
    const num = digits.slice(1, 5);
    let out = region;
    if (num) out += `-${num}`;
    if (region || num) out += "/";
    if (letters) out += letters;
    return out;
  };

  const formatCREFITO = (value: string) => {
    const digits = onlyDigits(value).slice(0, 6);
    const letters = onlyLetters(value).toUpperCase().slice(0, 2);
    let out = digits;
    if (digits.length === 6) out += "-F";
    if (letters) out += `/${letters}`;
    return out;
  };

  const formatCREFONO = (value: string) => {
    const digits = onlyDigits(value);
    const letters = onlyLetters(value).toUpperCase().slice(0, 2);
    const region = digits.slice(0, 1);
    const num = digits.slice(1, 6);
    let out = region;
    if (num) out += `-${num}`;
    if (region || num) out += "/";
    if (letters) out += letters;
    return out;
  };

  const formatNumber = (digits: string) => digits.replace(/^0+(?=\d)/, "");

  const formatValue = (val: string) => {
    switch (type) {
      case "cpf":
        return formatCPF(onlyDigits(val));
      case "rg":
        return formatRG(onlyDigits(val));
      case "birthDate":
        return formatBirthDate(onlyDigits(val));
      case "phone":
        return formatPhone(onlyDigits(val));
      case "cep":
        return formatCEP(onlyDigits(val));
      case "crm":
        return formatCRM(val);
      case "crp":
        return formatCRP(onlyDigits(val));
      case "crn":
        return formatCRN(val);
      case "crefito":
        return formatCREFITO(val);
      case "crefono":
        return formatCREFONO(val);
      case "number":
        return formatNumber(onlyDigits(val));
      default:
        return val;
    }
  };

  return { formatValue, sanitizeValue, allowLetters };
}
