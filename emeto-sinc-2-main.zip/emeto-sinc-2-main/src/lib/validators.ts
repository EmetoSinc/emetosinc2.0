import { z } from "zod";
import { differenceInYears } from "date-fns";

export function validateCPF(input: string): boolean {
  const cpf = (input || "").replace(/\D/g, "");
  if (!cpf || cpf.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(cpf)) return false; // repetidos

  const calcCheck = (base: string, factor: number) => {
    let total = 0;
    for (let i = 0; i < base.length; i++) total += parseInt(base[i], 10) * (factor - i);
    const mod = total % 11;
    return mod < 2 ? 0 : 11 - mod;
  };

  const d1 = calcCheck(cpf.slice(0, 9), 10);
  const d2 = calcCheck(cpf.slice(0, 10), 11);
  return cpf.endsWith(`${d1}${d2}`);
}

export const cpfSchema = z
  .string()
  .regex(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/, "CPF inválido")
  .refine(validateCPF, "CPF inválido");

export const rgSchema = z
  .string()
  .regex(/^\d{2}\.\d{3}\.\d{3}-\d{1}$/, "RG inválido");

export const phoneSchema = z
  .string()
  .regex(/^\(\d{2}\) \d{4,5}-\d{4}$/, "Telefone inválido");

export const cepSchema = z
  .string()
  .regex(/^\d{5}-\d{3}$/, "CEP inválido");

export const crmSchema = z
  .string()
  .regex(/^\d{6}\/[A-Z]{2}$/, "CRM inválido");

export const crpSchema = z
  .string()
  .regex(/^\d{2}\/\d{6}$/, "CRP inválido");

export const crnSchema = z
  .string()
  .regex(/^\d{1}-\d{4}\/[A-Z]{2}$/, "CRN inválido");

export const crefitoSchema = z
  .string()
  .regex(/^\d{6}-F\/[A-Z]{2}$/, "CREFITO inválido");

export const crefonoSchema = z
  .string()
  .regex(/^\d{1}-\d{5}\/[A-Z]{2}$/, "CREFONO inválido");

export const numberSchema = z.number().int("Deve ser um número inteiro").positive("Deve ser positivo");
export const numberStringSchema = z
  .string()
  .regex(/^\d+$/, "Deve conter apenas números");

export function parseBirthDateStringToDate(value: string): Date | null {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(value || "");
  if (!m) return null;
  const day = parseInt(m[1], 10);
  const month = parseInt(m[2], 10) - 1;
  const year = parseInt(m[3], 10);
  const d = new Date(year, month, day);
  // validate real date
  if (d.getFullYear() !== year || d.getMonth() !== month || d.getDate() !== day) return null;
  return d;
}

export const birthDateSchema = z
  .date()
  .max(new Date(), "Data não pode ser futura")
  .refine((date) => {
    const age = differenceInYears(new Date(), date);
    return age <= 130;
  }, "Idade não pode exceder 130 anos");

export const birthDateMaskedStringSchema = z
  .string()
  .regex(/^\d{2}\/\d{2}\/\d{4}$/i, "Data inválida")
  .transform((val, ctx) => {
    const d = parseBirthDateStringToDate(val);
    if (!d) ctx.addIssue({ code: z.ZodIssueCode.custom, message: "Data inválida" });
    return d as any;
  })
  .pipe(birthDateSchema);

// ========== CEP (ViaCEP) and Professional Registries ==========
export type ViaCepAddress = {
  street: string;
  neighborhood: string;
  city: string;
  state: string;
};

export type CepValidationResult =
  | { valid: true; address: ViaCepAddress }
  | { valid: false; error: string };

export async function validateCEP(cep: string): Promise<CepValidationResult> {
  try {
    const cleanCEP = (cep || '').replace(/\D/g, '');
    if (cleanCEP.length !== 8) {
      return { valid: false, error: 'Formato de CEP inválido' };
    }

    const response = await fetch(`https://viacep.com.br/ws/${cleanCEP}/json/`);
    const data = await response.json();

    if (data?.erro) {
      return { valid: false, error: 'CEP não encontrado' };
    }

    return {
      valid: true,
      address: {
        street: data.logradouro || '',
        neighborhood: data.bairro || '',
        city: data.localidade || '',
        state: data.uf || '',
      },
    };
  } catch (e) {
    return { valid: false, error: 'Erro ao verificar CEP' };
  }
}

export function validateProfessionalRegistry(
  registry: string,
  type: 'crm' | 'crp' | 'crn' | 'crefito' | 'crefono'
): boolean {
  switch (type) {
    case 'crm':
      // 123456/SP
      return /^\d{6}\/[A-Z]{2}$/.test(registry);
    case 'crp':
      // 06/123456
      return /^\d{2}\/\d{6}$/.test(registry);
    case 'crn':
      // 3-1234/SP
      return /^\d{1}-\d{4}\/[A-Z]{2}$/.test(registry);
    case 'crefito':
      // 123456-F/SP
      return /^\d{6}-F\/[A-Z]{2}$/.test(registry);
    case 'crefono':
      // 2-12345/SP
      return /^\d{1}-\d{5}\/[A-Z]{2}$/.test(registry);
    default:
      return false;
  }
}

export const cepViaCepSchema = z
  .string()
  .regex(/^\d{5}-\d{3}$/, 'Formato de CEP inválido')
  .refine(async (value) => {
    const result = await validateCEP(value);
    return result.valid;
  }, 'CEP não encontrado');

export const errorMessages = {
  cpf: {
    format: 'CPF deve ter o formato 000.000.000-00',
    invalid: 'CPF inválido (verifique os dígitos)',
  },
  cep: {
    format: 'CEP deve ter o formato 00000-000',
    notFound: 'CEP não encontrado nos Correios',
  },
  registry: {
    crm: 'CRM deve ter o formato 123456/SP',
    crp: 'CRP deve ter o formato 06/123456',
    crn: 'CRN deve ter o formato 3-1234/SP',
    crefito: 'CREFITO deve ter o formato 123456-F/UF',
    crefono: 'CREFONO deve ter o formato 2-12345/UF',
    invalid: 'Registro profissional inválido',
  },
} as const;
