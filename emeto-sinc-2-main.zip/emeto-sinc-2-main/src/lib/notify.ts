import { toast } from "@/components/ui/use-toast";
import type { ToastActionElement } from "@/components/ui/toast";

export type NotifyOptions = {
  duration?: number;
  action?: ToastActionElement;
};

function make(variant?: "error" | "success" | "warning" | "info") {
  return (title: string, description?: string, options?: NotifyOptions) =>
    toast({ title, description, variant, ...options });
}

export const notify = {
  success: make("success"),
  error: make("error"),
  warning: make("warning"),
  info: make("info"),
};

export default notify;
