
import { supabase } from "@/integrations/supabase/client";

export type UserType = 'gestor' | 'profissional' | 'flebotomista' | 'atendente';
export type ProfessionalSubtype =
  | 'medico'
  | 'psicologo'
  | 'nutricionista'
  | 'fisioterapeuta'
  | 'esteticista'
  | 'fonoaudiologo'
  | 'massoterapeuta'
  | 'terapeuta-ocupacional'
  | 'quiropraxista'
  | 'acupunturista'
  | 'osteopata'
  | 'psicanalista';

export interface Invitation {
  id: string;
  token: string;
  name: string;
  email: string;
  user_type: UserType;
  professional_type?: string | null;
  created_at: string;
  expires_at: string;
  used: boolean;
  invited_by: string | null;
}

export async function validateInvitationToken(token: string) {
  const { data, error } = await supabase.rpc('validate_invitation_token', { _token: token });
  if (error) throw error;
  return data as Invitation | null;
}

export async function markInvitationUsed(token: string) {
  const { error } = await supabase.rpc('mark_invitation_used', { _token: token });
  if (error) throw error;
}

export async function createInvitation(input: {
  name: string;
  email: string;
  user_type: UserType;
  professional_type?: string;
}) {
  // Usa a função RPC segura no banco para criar o convite
  const { data, error } = await supabase.rpc('create_invitation', {
    _name: input.name,
    _email: input.email,
    _user_type: input.user_type,
    _professional_type: input.professional_type ?? null,
  });

  if (error) throw error;
  return data as Invitation;
}

export function buildInviteUrl(token: string) {
  return `${window.location.origin}/registro?token=${token}`;
}

export function getRegistryMaskFromSubtype(type?: string) {
  switch ((type || '').toLowerCase()) {
    case 'medico':
      return 'crm';
    case 'psicologo':
      return 'crp';
    case 'nutricionista':
      return 'crn';
    case 'fisioterapeuta':
      return 'crefito';
    case 'fonoaudiologo':
      return 'crefono';
    default:
      return undefined;
  }
}
