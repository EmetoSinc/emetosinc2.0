# Input Universal Guidelines

Este documento define as diretrizes universais para componentes de input em nossos projetos, facilitando a reutilização e padronização.

## Modificações Aplicadas nos Inputs

### 1. Estilo de Foco
- **Removido**: `ring-offset-background`, `focus-visible:ring-2`, `focus-visible:ring-ring`, `focus-visible:ring-offset-2`
- **Adicionado**: `focus-visible:border-primary`
- **Resultado**: Borda azul primária direta no input, sem espaçamento externo

### 2. Classes Padrão do Input
```tsx
className={cn(
  "flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-base file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus:placeholder:text-transparent focus-visible:outline-none focus-visible:border-primary disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
  className
)}
```

### 3. Placeholder no Foco
- Regra universal: o placeholder deve desaparecer ao focar no campo
- Implementação: adicionar a classe Tailwind `focus:placeholder:text-transparent`
- Abrangência: aplicar em `Input` e `Textarea`

```tsx
// Exemplo resumido
className={cn(
  "... placeholder:text-muted-foreground focus:placeholder:text-transparent ..."
)}
```

### 4. Background Padrão do Input
- **Cor**: `#fafafa`
- **Implementação**: Aplicado globalmente via tailwind.config.ts
- **Regra**: `input { background-color: #fafafa !important }`

## Modificações Aplicadas nas Mensagens de Erro

### 1. Estilo da Mensagem
- **Tamanho da fonte**: `text-xs` (reduzido de `text-sm`)
- **Ícone**: Componente `AlertCircle` da lucide-react
- **Layout**: Flex com gap de 1.5 entre ícone e texto

### 2. Animação de Entrada
- **Keyframes personalizados**:
  ```css
  'slide-down-error': {
    from: {
      opacity: '0',
      transform: 'translateY(-8px)'
    },
    to: {
      opacity: '1',
      transform: 'translateY(0)'
    }
  }
  ```
- **Duração**: 0.3s com easing `ease-out`
- **Classe**: `animate-slide-down-error`

### 3. Estrutura do FormMessage
```tsx
return (
  <div className="animate-slide-down-error">
    <p className={cn("text-xs font-medium text-destructive flex items-center gap-1.5", className)}>
      <AlertCircle className="h-3 w-3 flex-shrink-0" />
      {body}
    </p>
  </div>
)
```

## Validação Não-Intrusiva

### Hook: useNonIntrusiveForm
- **Localização**: `src/hooks/useNonIntrusiveForm.ts`
- **Funcionalidade**: Controla quando erros aparecem (após submit, não durante digitação)
- **Uso**: Substitui `useForm` do react-hook-form

### Componente: NonIntrusiveFormField
- **Localização**: `src/components/ui/non-intrusive-form-field.tsx`
- **Funcionalidade**: Wrapper inteligente que integra automaticamente com validação não-intrusiva
- **Uso**: Substitui `FormField` padrão

## Implementação em Novos Projetos

1. **Copiar arquivos base**:
   - `src/hooks/useNonIntrusiveForm.ts`
   - `src/components/ui/non-intrusive-form-field.tsx`
   - Modificações no `src/components/ui/form.tsx`
   - Modificações no `src/components/ui/input.tsx`
   - Modificações no `src/components/ui/textarea.tsx`

2. **Adicionar animações no tailwind.config.ts**:
   ```js
   keyframes: {
     'slide-down-error': {
       from: { opacity: '0', transform: 'translateY(-8px)' },
       to: { opacity: '1', transform: 'translateY(0)' }
     }
   },
   animation: {
     'slide-down-error': 'slide-down-error 0.3s ease-out'
   }
   ```

3. **Instalar dependências**:
   - `lucide-react` (para ícone AlertCircle)

## Benefícios

- ✅ **UX Consistente**: Validação aparece apenas após submissão
- ✅ **Visual Elegante**: Borda primária sem espaçamento, ícones de erro
- ✅ **Animações Suaves**: Entrada de erro com slide-down em 0.3s
- ✅ **Reutilização**: Componentes padronizados para todos os projetos
- ✅ **Manutenibilidade**: Lógica centralizada e documentada

## 4. Altura Padrão dos Botões

### Botões Primários
- **Classe**: `py-2`
- **Altura**: `padding-top: 1.2rem; padding-bottom: 1.2rem`
- **Implementação**: Definido em `tailwind.config.ts`

### Uso
```tsx
<Button type="submit" className="w-full py-2">
  Texto do Botão
</Button>
```

### Implementação no tailwind.config.ts
```js
// Standard Button Heights
".py-2": {
  "padding-top": "1.2rem",
  "padding-bottom": "1.2rem"
}
```

## Inputs Específicos Brasileiros

## Inputs Específicos com Formatação Automática

### Implementação Obrigatória:
Todos os inputs abaixo DEVEM ter:
- Formatação em tempo real (conforme usuário digita)
- Validação de entrada (apenas números quando aplicável)
- Máscara visual automática
- Validação Zod correspondente

### CPF
```tsx
// Máscara: 000.000.000-00
// Regex: /^\d{3}\.\d{3}\.\d{3}-\d{2}$/
// Input: apenas números, formatação automática
// Validação: CPF válido + formato correto

const cpfSchema = z.string()
  .regex(/^\d{3}\.\d{3}\.\d{3}-\d{2}$/, 'CPF inválido')
  .refine(validateCPF, 'CPF inválido')
```

### RG
```tsx
// Máscara: 00.000.000-0
// Regex: /^\d{2}\.\d{3}\.\d{3}-\d{1}$/
// Input: apenas números, formatação automática

const rgSchema = z.string()
  .regex(/^\d{2}\.\d{3}\.\d{3}-\d{1}$/, 'RG inválido')
```

### Data de Nascimento
```tsx
// Máscara: DD/MM/AAAA
// Limitações: dia ≤ 31, mês ≤ 12, ano ≤ 4 dígitos
// Validações: não futuro, não > 130 anos

const birthDateSchema = z.date()
  .max(new Date(), 'Data não pode ser futura')
  .refine(date => {
    const age = differenceInYears(new Date(), date)
    return age <= 130
  }, 'Idade não pode exceder 130 anos')
```

### Telefone
```tsx
// Máscara: (00) 00000-0000 ou (00) 0000-0000
// Input: apenas números, formatação automática

const phoneSchema = z.string()
  .regex(/^\(\d{2}\) \d{4,5}-\d{4}$/, 'Telefone inválido')
```

### CEP
```tsx
// Máscara: 00000-000
// Input: apenas números, formatação automática

const cepSchema = z.string()
  .regex(/^\d{5}-\d{3}$/, 'CEP inválido')
```

### Número (campos numéricos)
```tsx
// Input: apenas números, sem formatação
// Validação: integer positivo

const numberSchema = z.number()
  .int('Deve ser um número inteiro')
  .positive('Deve ser positivo')
```

### Registros Profissionais

#### CRM (Conselho Regional de Medicina)
```tsx
// Máscara: 000000/UF
// Exemplo: 123456/SP

const crmSchema = z.string()
  .regex(/^\d{6}\/[A-Z]{2}$/, 'CRM inválido')
```

#### CRP (Conselho Regional de Psicologia)
```tsx
// Máscara: 00/000000
// Exemplo: 06/123456

const crpSchema = z.string()
  .regex(/^\d{2}\/\d{6}$/, 'CRP inválido')
```

#### CRN (Conselho Regional de Nutricionistas)
```tsx
// Máscara: 0-0000/UF
// Exemplo: 3-1234/SP

const crnSchema = z.string()
  .regex(/^\d{1}-\d{4}\/[A-Z]{2}$/, 'CRN inválido')
```

#### CREFITO (Conselho Regional de Fisioterapia)
```tsx
// Máscara: 000000-F/UF
// Exemplo: 123456-F/SP

const crefitoSchema = z.string()
  .regex(/^\d{6}-F\/[A-Z]{2}$/, 'CREFITO inválido')
```

#### CREFONO (Conselho Regional de Fonoaudiologia)
```tsx
// Máscara: 0-00000/UF
// Exemplo: 2-12345/SP

const crefonoSchema = z.string()
  .regex(/^\d{1}-\d{5}\/[A-Z]{2}$/, 'CREFONO inválido')
```

## Implementação Técnica

### Hook de Formatação:
```tsx
const useMask = (type: 'cpf' | 'rg' | 'birthDate' | 'phone' | 'cep' | 'crm' | 'crp' | 'crn' | 'crefito' | 'crefono' | 'number') => {
  const formatValue = (value: string) => { /* ... */ }
  return { formatValue }
}
```

### Componente Input com Máscara:
```tsx
interface MaskedInputProps {
  mask: 'cpf' | 'rg' | 'birthDate' | 'phone' | 'cep' | 'crm' | 'crp' | 'crn' | 'crefito' | 'crefono' | 'number'
  value: string
  onChange: (value: string) => void
}

const MaskedInput = ({ mask, value, onChange }: MaskedInputProps) => {
  const { formatValue } = useMask(mask)
  return (
    <Input
      value={value}
      onChange={(e) => onChange(formatValue(e.target.value))}
      placeholder={getMaskPlaceholder(mask)}
    />
  )
}
```

### Regras de Implementação

1. Formatação em tempo real durante digitação
2. Entrada apenas numérica (exceto UF nos registros profissionais)
3. Validação Zod correspondente
4. Mensagens de erro claras
5. Placeholder com exemplo da formatação

### Uso nos Formulários:
```tsx
// Exemplo de uso no cadastro de usuário
<MaskedInput
  mask="cpf"
  value={formData.cpf}
  onChange={(value) => setFormData(prev => ({ ...prev, cpf: value }))}
/>
```
